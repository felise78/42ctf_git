# 42git_ctf

Welcome young cadet !
We need you to complete our golden rules list !
We've already rebuild it but one is still missing...

Because of the integration week we don't have time to find out the last one, it's time to show what you can do :)
As we are nice people (yes we are, indeed) here are some information to help you :

  - git is a powerfull tool to save/restore/split/share/update your work;

  - if you use BRANCH wisely and if your COMMIT message is clear and detailed it will be easy to navigate in the repository
    using some --easy-to-find git command;

  - remember git is used for versioning, so same stuff can has several versions, and it's always possible to CHECK olders...

  - you can easily create and update features independently then MERGE them, or simply REBASE feature_1 branch on feature_2 branch to update version of feature_2 in feature_1 branch;

  - you can also look for DIFF between local and distant file;

  - sometimes conflict may happens, it's up to you to avoid it or in case, manage it in a clever way;

  - beware, some stuff can disapear from your history, but still be present on your repository for a few time...

ONLY GIT COMMANDS ARE ALLOWED, you are NOT authorized to modify the source code;

When you are done send me the flag.

Good luck young recruit !
